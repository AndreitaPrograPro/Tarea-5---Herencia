import java.util.ArrayList;

public class Automovil extends Vehiculo {
    

    private int cantidadPasajeros;
    private boolean transmisionAutomatica;

    public Automovil(String placa, String marca, String modelo, double tarifaDiaria, int cantidadPasajeros, boolean transmisionAutomatica) {

        super(placa, marca, modelo, tarifaDiaria);

        if (cantidadPasajeros <= 0) {
            throw new IllegalArgumentException(
                "La cantidad de pasajeros debe ser mayor que cero."
            );
        }

        this.cantidadPasajeros = cantidadPasajeros;
        this.transmisionAutomatica = transmisionAutomatica;
    }
    public int getCantidadPasajeros() {
    return cantidadPasajeros;
    }

    public boolean isTransmisionAutomatica() {
        return transmisionAutomatica;
    }
    @Override
    public double calcularSubtotal(int dias) {
        if (dias <= 0) {
            throw new IllegalArgumentException(
                "Los dias deben ser mayores que cero."
            );
        }

        double subtotal = getTarifaDiaria() * dias;

        if (transmisionAutomatica) {
            subtotal += 50 * dias;
        }

        return subtotal;
    }
    @Override
    public boolean aceptaLicencia(ArrayList<String> licencias) {
        if (licencias == null) {
            return false;
        }

        return licencias.contains("C")
            || licencias.contains("B")
            || licencias.contains("A");
    }
    @Override
    public int getUmbralMantenimiento() {
        return 30;
    }
    @Override
    public String getDescripcion() {
        String transmision;

        if (transmisionAutomatica) {
            transmision = "Automatica";
        } else {
            transmision = "Manual";
        }

        return "Automovil | Pasajeros: " + cantidadPasajeros
            + " | Transmision: " + transmision;
    }

}
