import java.util.ArrayList;

public class Motocicleta extends Vehiculo {

    private int cilindraje;

    public Motocicleta(String placa, String marca, String modelo, double tarifaDiaria, int cilindraje) {

        super(placa, marca, modelo, tarifaDiaria);

        if (cilindraje <= 0) {
            throw new IllegalArgumentException(
                "El cilindraje debe ser mayor que cero."
            );
        }

        this.cilindraje = cilindraje;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    @Override
    public double calcularSubtotal(int dias) {
        if (dias <= 0) {
            throw new IllegalArgumentException(
                "Los dias deben ser mayores que cero."
            );
        }

        double subtotal = getTarifaDiaria() * dias;

        if (cilindraje > 250) {
            subtotal += 75;
        }

        return subtotal;
    }

    @Override
    public boolean aceptaLicencia(ArrayList<String> licencias) {
        if (licencias == null) {
            return false;
        }

        return licencias.contains("M");
    }

    @Override
    public int getUmbralMantenimiento() {
        return 20;
    }

    @Override
    public String getDescripcion() {
        return "Motocicleta | Cilindraje: " + cilindraje + " cc";
    }

}