import java.util.ArrayList;

public class CamionetaCarga extends Vehiculo {

    private double capacidadToneladas;

    public CamionetaCarga(String placa, String marca, String modelo,
                          double tarifaDiaria, double capacidadToneladas) {

        super(placa, marca, modelo, tarifaDiaria);

        if (!Double.isFinite(capacidadToneladas) || capacidadToneladas <= 0) {
            throw new IllegalArgumentException(
                "La capacidad debe ser un numero positivo y finito."
            );
        }

        this.capacidadToneladas = capacidadToneladas;
    }

    public double getCapacidadToneladas() {
        return capacidadToneladas;
    }

    @Override
    public double calcularSubtotal(int dias) {
        if (dias <= 0) {
            throw new IllegalArgumentException(
                "Los dias deben ser mayores que cero."
            );
        }

        double costoBase = getTarifaDiaria() * dias;
        double recargo = 100 * capacidadToneladas * dias;

        return costoBase + recargo;
    }

    @Override
    public boolean aceptaLicencia(ArrayList<String> licencias) {
        if (licencias == null) {
            return false;
        }

        return licencias.contains("B")
            || licencias.contains("A");
    }

    @Override
    public int getUmbralMantenimiento() {
        return 15;
    }

    @Override
    public String getDescripcion() {
        return "Camioneta de carga | Capacidad: "
            + capacidadToneladas + " toneladas";
    }
}